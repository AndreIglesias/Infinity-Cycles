from tkinter import *
import random
from time import sleep
from fractal import *

class target:
    """
    Documentation for target
    """
    def __init__(self, canvas, x, y):
        super(target, self).__init__()
        self.canvas = canvas
        self.x = x
        self.y = y
        
        color = ['gold', 'blue', 'snow', 'yellow', 'tomato', 'orange']
        r = lambda: random.randint(0,5)
        if r()%2 == 0:
            self.figura = canvas.create_oval(x-35, y-35, x+35, y+35, fill = color[r()], tags = 'token', width = 4, outline = 'green')
        else:
            self.figura = canvas.create_oval(x-35, y-35, x+35, y+35, fill = color[r()], outline = 'black', width = 0)




        
def generateShape(event = None):
    a = 0
    sha = target(canvas, event.x, event.y)
    x, y, a, b = canvas.coords(sha.figura)
    Tags = canvas.find_overlapping(x, y, a, b)
    print('--------------------------------------------')
    lista = []
    for i in Tags:
        if canvas.gettags(i) != ():
            #print(i, canvas.gettags(i))   
            lista.append(canvas.gettags(i)[0])
    #print(lista)
    if lista.count('token') >= 2:
        canvas.delete('all')
        canvas.create_rectangle(0, 0, 1100, 750, fill = 'gray20')
        r = lambda: random.randint(0,300)
        fa.Fractal(None, r(), r(), 'white', 1, 7)
        sleep(0.5)

tk = Tk()
canvas = Canvas(tk, width = 1100, height = 750, bg = 'gray20')
canvas.pack()

fa = Fractal(canvas)
r = lambda: random.randint(0,300)
fa.Fractal(None, r(), r(), 'white', 1, 7)
canvas.bind('<ButtonPress-1>', generateShape)

mainloop()
